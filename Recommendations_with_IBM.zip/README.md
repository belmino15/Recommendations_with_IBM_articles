# Recommendations system with IBM articles
---------------------------------------------------

## Objective
Analyze the interactions that users have with articles on the IBM Watson Studio platform, and make recommendations to them about new articles we think they will like.
